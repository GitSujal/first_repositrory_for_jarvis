# jasper_modules
my jasper modules


send text v2

send sms messages with textbelt http://textbelt.com

requirements:

StringIO

pycurl
sudo apt-get install python-pycurl
